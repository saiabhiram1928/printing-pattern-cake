
#include <stdio.h>

int main()
{ int a,i,j;
for(i=1;i<5;i++){
    if(i==1){
        for(a=1;a<=4;a++){
            printf("-");
        } 
    printf("\n");
        
    }
    if(i!=0){
        for(j=1;j<=4;j++){
            if(j==1){
                printf("-");
            }
            if(j==2 || j==3){
                printf(" ");
            }
        if(j==4){
            printf("-\n");
        }
            
        }
    }
}
    

    return 0;
}
